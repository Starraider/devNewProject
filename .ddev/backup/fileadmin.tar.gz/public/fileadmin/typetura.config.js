window.typetura = {
  selectors: [
    ':root',
    '.typetura',
    'main',
    'article',
    'section',
    'aside',
    'contentcontainer-column',
  ],
}
